﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] vector = new int[] { 12, -34, 40, 6, -10, 56, 12, -1, -15, 10, 4 };
            findMax(vector);
            Console.ReadKey();
        }

        public static void findMax(int[] vector){
            int start = 0;
            int end = 0;
            int max  = vector[0];
            int sum = max;
            for(int i = 1; i < vector.Length; i++){
                if(sum + vector[i]> vector[i]){
                    sum += vector[i];
                }
                else{
                    sum = vector[i];
                    if(sum>max){
                        start = i;
                    }
                }
                if(max<sum){
                    end = i;
                    max = sum;
                }
            }
            Console.WriteLine("Start index is " + start + " ,end index is " + end + " and the sum is " + max);
        }
 
    }
}

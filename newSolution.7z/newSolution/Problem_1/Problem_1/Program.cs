﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string haystack = "vnk2435kvabco8awkh125kjneytbcd12qjhb4acd123xmnbqwnw4t";
            string needle = "abcd1234";
            int threshold = 3;

            findOcurrence(haystack, needle, threshold);
            Console.ReadKey();
        }

        public static void findOcurrence(string hay, string need, int threshold)
        {
            int start = 0;
            int? hayOffset = null;
            int? needOffset = null;
            string ocurrence = "";
            for(int i = 0; i< hay.Length; i++)
            {
                for(int j=start; j< need.Length; j++)
                {
                    if(hay[i] == need[j])
                    {
                        ocurrence += hay[i];
                        start = j+1;
                        if (hayOffset == null && needOffset == null)
                        {
                            hayOffset = i;
                            needOffset = j;
                        }
                        break;
                    }
                    else
                    {
                        if (ocurrence.Length >= threshold)
                        {
                            Console.WriteLine("sequence of length = " + ocurrence.Length + " found at haystack offset " + hayOffset + ", needle offset " + needOffset);
                        }
                        ocurrence = "";
                        start = 0;
                        hayOffset = null;
                        needOffset = null;
                        if (j + threshold > need.Length - 1)
                        {
                            break;
                        }
                    }

                }
            }

            
        }
    }
}
